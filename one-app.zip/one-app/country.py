import pandas as pd
from app.models import Country
from app.db import session as db

df = pd.read_csv("Country Information.csv")
data = []
for i, row in df.iterrows():
     country = Country(
     iso = row['ISO'],
     iso3 = row['ISO3'],
     iso_numeric = row['ISO-Numeric'],
     fips = row['fips'],
     country = row['Country'],
     capital = row['Capital'],
     area = row['Area(in sq km)'],
     population = row['Population'],
     continent = row['Continent'],
     tld = row['tld'],
     currency_code = row['CurrencyCode'],
     currency_name = row['CurrencyName'],
     phone_code = row['Phone'],
     postal_code = row['Postal Code Format'],
     postal_code_regx = row['Postal Code Regex'],
     language = row['Languages'],
     geonameid = row['geonameid'],
     neighbours = row['neighbours'],
     equivqlent_fips_code = row['EquivalentFipsCode'])
     data.append(country)

db.add_all(data)
db.commit()