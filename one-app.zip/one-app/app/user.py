from flask import Blueprint, session, redirect, url_for, render_template, request, flash
from nltk.corpus import wordnet
from app.db import session as db
from app.models import Employee, Country

bp = Blueprint("user", __name__, url_prefix="/")


@bp.route("/home")
def home():
    if session["userid"]:
        return render_template("home.html")
    return redirect(url_for("home.login"))


@bp.route("/employee")
def employee():
    if not session["userid"]:
        return redirect(url_for("home.login"))
    employees = db.query(Employee).all()
    return render_template("employee.html", employees=employees)

@bp.route("/add-employee", methods=("POST",))
def add_employee():
    data = dict(request.form)
    emp = db.query(Employee).filter(Employee.email == data.get("email")).first()
    if emp:
        flash("Email Already Exists", category="error")
        return redirect(url_for("home.employee"))

    new_employee = Employee(**data)
    db.add(new_employee)
    db.commit()
    flash("New Employee Added", category="success")
    return redirect(url_for("home.employee"))

@bp.route("/search")
def search():
    return render_template("extended-search.html")

@bp.route("/wordnet", methods=("GET", "POST"))
def synonyms():
    if request.method == "POST":
        word = request.form.get("word")
        synonyms_list = {
            lemma.name()
            for synset in wordnet.synsets(word)
            for lemma in synset.lemmas()
        }
        return render_template("wordnet.html", synonyms_list=synonyms_list, word=word)
    return render_template("wordnet.html")

@bp.route("/location", methods=("GET", "POST"))
def location():
    
    country_list = db.query(Country.country).all()
    country = None
    if request.method == "POST":
        country = db.query(Country).filter(Country.country == request.form.get("country")).first()
    return render_template("location.html", countryList=country_list, result=country)