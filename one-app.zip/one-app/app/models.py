from sqlalchemy import Column, Integer, String
from sqlalchemy.sql.expression import null
from app.db import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False, unique=True)
    password = Column(String, nullable=False)

    def __str__(self) -> str:
        return f"<User(id={self.id}, name='{self.name}')>"


class Employee(Base):
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False, unique=True)
    company = Column(String, nullable=False)
    country = Column(String, nullable=False)

    def __str__(self) -> str:
        return f"<Employee(id={self.id}, name='{self.name}')>"

class Country(Base):
    __tablename__  = "countries"

    id = Column(Integer, primary_key=True)
    iso = Column(String, nullable=True)
    iso3 = Column(String, nullable=True)
    iso_numeric = Column(Integer, nullable=True)
    fips = Column(String, nullable=True)
    country = Column(String, nullable=True)
    capital = Column(String, nullable=True)
    area = Column(String, nullable=True)
    population = Column(String, nullable=True)
    continent = Column(String, nullable=True)
    tld = Column(String, nullable=True)
    currency_code = Column(String, nullable=True)
    currency_name = Column(String, nullable=True)
    phone_code = Column(String, nullable=True)
    postal_code = Column(String, nullable=True)
    postal_code_regx = Column(String, nullable=True)
    language = Column(String, nullable=True)
    geonameid = Column(String, nullable=True)
    neighbours = Column(String, nullable=True)
    equivqlent_fips_code = Column(String, nullable=True)
