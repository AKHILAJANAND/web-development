import nltk
from flask import Flask
from app.models import Base


def create_app():
    nltk.download("wordnet")
    app = Flask(__name__)
    app.secret_key = "TestSecretKey"
    Base.metadata.create_all()
    from app import home
    app.register_blueprint(home.bp)
    from app import user
    app.register_blueprint(user.bp)
    return app