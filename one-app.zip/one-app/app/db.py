from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.session import Session

DATABASE_URL = "sqlite:///one-app.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

Base = declarative_base(bind=engine)

DBSession = sessionmaker(bind=engine, autocommit=False, autoflush=False)

session: Session = DBSession()
