from flask import Blueprint, render_template, redirect, flash, request, session
from flask.helpers import url_for
from werkzeug.security import generate_password_hash, check_password_hash
from app.db import session as db
from app.models import User, Employee

bp = Blueprint("home", __name__, url_prefix="/")

@bp.route("/")
def index():
    # flash("Success Message", category="error")
    return render_template("index.html")

@bp.route("/register", methods=("GET", "POST"))
def register():
    if request.method == "POST":
        data = dict(request.form)
        password = data.get("password")
        cpassword = data.get("cpassword")
        if not password == cpassword:
            flash("Password Missmatch", category="error")
        else:
            user = db.query(User).filter(User.email == data.get("email")).first()
            if not user:
                data.pop("password")
                data.pop("cpassword") 
                password = generate_password_hash(password)
                data["password"] = password
                user = User(**data)
                db.add(user)
                db.commit()
                flash("Registration Success")
                return redirect(url_for("home.login"))
            else:
                flash("Email ID Already Exists", category="error")
    return render_template("register.html")

@bp.route("/login", methods=("GET", "POST"))
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user = db.query(User).filter(User.email == email).first()
        if user and check_password_hash(user.password, password):
            session.clear()
            session["userid"] = user.id
            flash("Login Success")
            return redirect(url_for("user.home"))
        else:
            flash("Credentials Missmatch", category="error")

    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home.index"))

